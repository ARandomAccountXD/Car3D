﻿using UnityEngine;

public class CarController : MonoBehaviour
{
	public float speed = 10.0f;
	public float turnSpeed = 50.0f;

	void Update()
	{
		// Movimiento hacia adelante y atrás
		float moveDirection = Input.GetAxis("Vertical") * speed * Time.deltaTime;
		transform.Translate(0, 0, moveDirection);

		// Girar el coche
		float turnDirection = Input.GetAxis("Horizontal") * turnSpeed * Time.deltaTime;
		transform.Rotate(0, turnDirection, 0);
	}
}
